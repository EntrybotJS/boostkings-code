---
title: What was Wayne's World?
category: General
---

Wayne's World is a 1992 American comedy film directed by Penelope Spheeris and starring Mike Myers as Wayne Campbell and Dana Carvey as Garth Algar. The film was adapted from a sketch of the same name on NBC's Saturday Night Live.

<!-- more -->

The film grossed US$121.6 million in its theatrical run, placing it as the tenth highest-grossing film of 1992 and the highest-grossing of the 11 films based on Saturday Night Live skits. It was filmed in 34 days.

Wayne's World was Myers' feature film debut. It also features Rob Lowe, Tia Carrere, Lara Flynn Boyle, Brian Doyle-Murray, Robert Patrick (spoofing his role in Terminator 2: Judgment Day), Chris Farley, Ed O'Neill, Ione Skye, Meat Loaf, and Alice Cooper. Wayne's World was released on February 14, 1992, and was a critical and commercial success. A sequel, Wayne's World 2, was released on December 10, 1993. In 2000, readers of Total Film magazine voted Wayne's World the 41st-greatest comedy film of all time.

_Originally from [Wayne's World (film) - Wikipedia](https://en.wikipedia.org/wiki/Wayne%27s_World_(film))_
