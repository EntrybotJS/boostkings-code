---
title: Who is Mike Myers?
category: People
---

Michael John "Mike" Myers (born May 25, 1963) is a Canadian-born actor, comedian, screenwriter, and film producer, who also holds UK and US citizenship.[1] He is known for his run as a featured performer on Saturday Night Live from 1989 to 1995, and for playing the title roles in the Wayne's World, Austin Powers, and Shrek films. He also directed the documentary film Supermensch: The Legend of Shep Gordon, and had a small role in Quentin Tarantino's Inglourious Basterds in 2009.

<!-- more -->

Myers was born on May 25, 1963 in Scarborough, Ontario, the son of English-born parents Eric Myers (1922–1991), an insurance agent, and his wife, Alice E. (née Hind; born 1926), an office supervisor and a veteran of the Royal Air Force.

Both his parents were from Liverpool and he has two older brothers, Paul, an indie rock singer-songwriter, broadcaster and author, and Peter, a Sears Canada employee.

The family is of English, Scottish and Irish ancestry. Myers was raised Protestant.

Myers reportedly holds Canadian, U.S. and British citizenship.

Myers grew up in North York and then Scarborough, where he attended Sir John A. MacDonald Collegiate Institute and then graduated from Stephen Leacock Collegiate Institute in 1982.

_Originally from [Mike Myers - Wikipedia](https://en.wikipedia.org/wiki/Mike_Myers)_
