---
title: Who is Dana Carvey?
category: People
---

Dana Thomas Carvey (born June 2, 1955) is an American actor and stand-up comedian known for his work as a cast member on Saturday Night Live and for playing the role of Garth Algar in the Wayne's World films.

<!-- more -->

Carvey was born in Missoula, Montana, the son of Billie Dahl, a schoolteacher, and Bud Carvey, a high-school business teacher. Carvey is the brother of Brad Carvey, the engineer/designer of the Video Toaster. The character Garth Algar is loosely based on Brad. Carvey has English, German, Irish, Norwegian, and Swedish ancestry, and was raised Lutheran. When he was three years old, his family moved to San Carlos, California, in the San Francisco Bay Area. He received his first drum kit at an early age. He attended Tierra Linda Junior High in San Carlos, Carlmont High School in Belmont, California (where he was a member of the Central Coast Section champion cross country team), College of San Mateo in San Mateo, California, and received his bachelor's degree in broadcast communications from San Francisco State University.

He had a minor role in Halloween II, and co-starred on One of the Boys in 1982, a short-lived television sitcom that also starred Mickey Rooney, Nathan Lane, and Meg Ryan. In 1984, Carvey had a small role in Rob Reiner's film This Is Spinal Tap, in which he played a mime, with fellow comedian Billy Crystal (who tells him "Mime is money!"). He also appeared in the short-lived film-based action television series Blue Thunder.

_Originally from [Dana Carvey - Wikipedia](https://en.wikipedia.org/wiki/Dana_Carvey)_
